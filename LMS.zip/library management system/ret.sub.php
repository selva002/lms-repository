<?php
session_start();
if(isset($_SESSION["user"])){
    header("location:index.php");
    exit();
}

?>


<?php
require_once 'db.php';

if(isset($_POST['submit']))
 {
	if(empty($_POST['UserID']) || empty($_POST['BookID']))
		
		{
			echo "please fill in the blanks";
		}
		else
		{

$UserID = $_POST['UserID'];
$BookID = $_POST['BookID'];
$Return = date("Y-m-d h:i:s a");


$query = "UPDATE management SET Return_Date='$Return' WHERE User_ID='$UserID' AND Book_ID='$BookID'";
$result = mysqli_query($conn,$query);


if($result)
 {
	
	header("location:view3.php");
 }
else
		{
			echo 'please check query';
		}

}
}
else
{
	header("location:index.php");
}

