<?php
session_start();

?>
<?php

require_once 'db.php';
  
if(isset($_POST['submit']))
  
	
{
	    $id = $_SESSION['id'];
	    $check = $_POST['order'];
   	    $Issue = date("Y-m-d h:i:s a");
	 
	  
	  
	if(is_array($check)){
	
	if(empty($check))
	{
		echo 'please select any one';
	}
	else{
	$n = count($check) ;

	for($i=0; $i<$n ;$i++)
	{
    $query = "insert into management(User_ID,Book_ID,Issue_Date) values('$id','$check[$i]','$Issue')";
	
    $result = mysqli_query($conn,$query);
   if($result)
   {
	   header("location:view2.php");
   }	   
   else{
	   echo 'please check query';
   }
	}
	}
	}
}

	
	?>