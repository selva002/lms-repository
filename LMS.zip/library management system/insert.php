<?php

require_once('db.php');

if(isset($_POST['Register']))
	
{        $UserName = $_POST['UserName'];
		 $UserPassword = $_POST['Password'];
		 $UserAddress = $_POST['Address'];
	
	if(empty($_POST['UserName']) || empty($_POST['Password']) || empty($_POST['Address']))
	{
		
	echo "<script>alert('user should  not empty')</script>";
	echo "<script>location.href='register.php'</script>";
	}
	else
	{
        
      
	  /*else{
		$UserName = $_POST['UserName'];
		
		$UserPassword = $_POST['Password'];
		$UserAddress = $_POST['Address'];*/
		
		$query = "insert into Register(User_Name,Password,Address) values('$UserName','$UserPassword','$UserAddress')";
		
		$result = mysqli_query($conn,$query);
		
		if($result)
		{
		header("location:view.php");
	
		}
		else
		{
			echo 'please check the query';
		}
}
} 
  else
	    {
		header("location:Register.php");
	    }
	
?>