<?php

require_once 'db.php';

?>
<!DOCTYPE html>
<html>
<head>
<title> home page </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="cs/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
  
</head>

 <body class="first" data-spy="scroll" data-target=".navbar" data-offset="50">
<header>

<div class="container">
<div class="navbar-header">
	  <img src="logo/logo1.png" alt="logo" class="col-sm-offset-0 col-sm-3">
    </div>
	</nav>
	</header>
	</div>
	
	<div class="container">
<div class="well col-sm-offset-4 col-sm-4 bg-secondary text-white"style="text-align:center;"><a href="book.php">Managements</a></div>
</div>

<div class="container">
<div class="well col-sm-offset-4 col-sm-4 bg-secondary text-white"style="text-align:center;"><a href="return.php">Return Book</a></div>
</div>

<div class="container">
<div class="well col-sm-offset-4 col-sm-4 bg-secondary text-white"style="text-align:center;"><a href="uvbook.php">submited Books</a></div>
</div>

      
    
</div>
</section>




</body>
</html>







