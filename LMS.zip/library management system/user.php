<!DOCTYPE html>
<html>
<head>
<title> index page </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="cs/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body  style="background-image:url(cs/library1.jpg);background-size:cover;">



<div class="container">

<div class="col-md-12" >
<h1 class="col-md-offset-3 text-info">&nbsp  Library Management System</h1></div>
</div>



&nbsp &nbsp


<div class="container" id="form">
<div class="row">
<div class="col-md-offset-4 col-md-4">

<h2 class="text-info"> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  User Login </h2>
<form action="login.php" method="POST">
<input type="text" name="UserName" placeholder="UserName" id= "USerName" size="25" class="form-control">
<input type="password" name="Password" placeholder="Password" id= "Password" size="25" class="form-control"></br>

<button type="submit" name="login" class="btn btn-info form-control">Login</button>&nbsp &nbsp

<button type="button" class="btn btn-success form-control"><a href="register.php">register</a></button>
</form>

</div>
</div>
</div>
</body>
</html>