<?php
require_once 'db.php';
$query = "select * from books_library";
$result = mysqli_query($conn,$query);

?>



<!DOCTYPE html>
<html>
<head>
<title> home page </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="cs/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  

<script>
function valueChanged(){
    if (document.getElementById('click').checked) 
        {document.getElementByClassName("hide").style.display = 'none';
    }
    else
        document.getElementById("hide").style.display = 'block';
    }
</script>
  
  
</head>
<body style="background-image:url(cs/library1.jpg);background-size:cover ">
<div class="container">
<div>

<h3 class="well col-sm-offset-4 col-sm-4 bg-secondary text-white" style="text-align:center"> Welcome Library </h3>
</div>
</div>

<div class="container">


<div class="table-responsive" >
<table class="table">

<tr class="text-success">

<td>Book ID </td>
<td>Book Name</td>
<td>Author Name </td>
<td>Edition </td>
<td> buy </td>
<td></td>

	
</tr>


 <form action="buybook.php" method="POST">
 
 <?php
 
 while ( $row = mysqli_fetch_assoc($result))
 { 

	 $BookID = $row['Book_ID'];
	 $BookName = $row['Book_Name'];
	 $AuthorName = $row['Author_Name'];
	 $Edition = $row['edition'];
	 
	 
	 
	 
	
 
 
 ?>
 <div  class="text-info"style="display:block;">
 <tr class="text-info">
 
 <td><input type="text" class="hide" ><?php echo $BookID ?> </td>
<td><?php echo $BookName ?></td>
<td><?php echo $AuthorName?></td>
<td><?php echo $Edition ?></td>
<td><input type="checkbox" name="order[]" id="click" onchange="valueChanged()" value="<?php echo $BookID; ?>"></td>
<td><input type="hidden" name = "user[]" value="<?php echo $UserID; ?>"></td>
<td><input type="date" name = "date[]" hidden value="<?php echo $Issue; ?>"></td>


	
 </tr>
 </div>
 <?php
 }
 ?>
 
 <input type="submit" name="submit" value="submit" class="btn btn-info" style="float:right";>
 </form>
 
  
 </table>
 </div>
 
 </div>
 </div>
 </div>
 <form action="logout.php">
 <div style="text-align:center;">
 <input type="submit" name="submit" value="logout" class="btn btn-warning">
 </form>
 </div>
 </body>
</html>