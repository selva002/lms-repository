
<?php
require_once 'db.php';

?>
<!DOCTYPE html>
<html>
<head>
<title> view page </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="well col-sm-offset-4 col-sm-4 bg-secondary text-white">thank you for the registration <a href="user.php"> go to main page </a>
</div>
